
/*
 * Name: Kwasi Kyeremeh
 * CRN: 202030
 * 3/22/20
 * class: Computer Science
 */




public class CryptoManager {

	private static final char LOWER_BOUND = ' ';
	private static final char UPPER_BOUND = '_';
	private static final int RANGE = UPPER_BOUND - LOWER_BOUND + 1;

	/**
	 * This method determines if a string is within the allowable bounds of ASCII
	 * codes according to the LOWER_BOUND and UPPER_BOUND characters
	 * 
	 * @param plainText
	 *            a string to be encrypted, if it is within the allowable bounds
	 * @return true if all characters are within the allowable bounds, false if any
	 *         character is outside
	 */
	public static boolean stringInBounds(String plainText) {
		// throw new RuntimeException("method not implemented");

		boolean evaluation = true;
		for (int i = 0; i < plainText.length(); i++) {

			if (plainText.charAt(i) == 'E' && plainText.charAt(i + 1) == 'S' && plainText.charAt(i + 2) == 'C') {
				evaluation = false;
				if (evaluation == false) {
					break;
				}
			}

			if (((plainText.charAt(i)) > 31) && ((plainText.charAt(i)) < 'Z')) {
				evaluation = true;

			} else {
				evaluation = false;
				if (evaluation == false) {
					break;
				}
			}
		}

		return evaluation;
	}

	/**
	 * Encrypts a string according to the Caesar Cipher. The integer key specifies
	 * an offset and each character in plainText is replaced by the character
	 * \"offset\" away from it
	 * 
	 * @param plainText
	 *            an uppercase string to be encrypted.
	 * @param key
	 *            an integer that specifies the offset of each character
	 * @return the encrypted string
	 */
	public static String encryptCaesar(String plainText, int key) {
		// throw new RuntimeException("method not implemented");
		String encryptedCode = "";
		int x = 0;
		for (int i = 0; i < plainText.length(); i++) {

			while ((plainText.charAt(i) + key) < 31 || (plainText.charAt(i) + key > 95)) {
				key = key - 64;
			}
			x = (plainText.charAt(i) + key - 65) + 65;

			encryptedCode += (char) x;
		}

		return encryptedCode;
	}

	/**
	 * Encrypts a string according the Bellaso Cipher. Each character in plainText
	 * is offset according to the ASCII value of the corresponding character in
	 * bellasoStr, which is repeated to correspond to the length of plainText
	 * 
	 * @param plainText
	 *            an uppercase string to be encrypted.
	 * @param bellasoStr
	 *            an uppercase string that specifies the offsets, character by
	 *            character.
	 * @return the encrypted string
	 */
	public static String encryptBellaso(String plainText, String bellasoStr) {
		// throw new RuntimeException("method not implemented");
		int j = 0;
		String extendedKey = "";
		String encryptedCode = "";
		for (int i = 0; i < plainText.length(); i++) {

			int v = bellasoStr.length();
			if (j == v) {
				j = 0;
			}

			extendedKey += (bellasoStr.charAt(j));
			j++;

		}

		int z = 0;

		for (int i = 0; i < plainText.length(); i++) {

			z = ((plainText.charAt(i) + extendedKey.charAt(i)));
			while (z > 95) {
				z = z - 64;
			}
			// z+='A';
			encryptedCode += (char) z;
		}

		return encryptedCode;
	}

	/**
	 * Decrypts a string according to the Caesar Cipher. The integer key specifies
	 * an offset and each character in encryptedText is replaced by the character
	 * \"offset\" characters before it. This is the inverse of the encryptCaesar
	 * method.
	 * 
	 * @param encryptedText
	 *            an encrypted string to be decrypted.
	 * @param key
	 *            an integer that specifies the offset of each character
	 * @return the plain text string
	 */
	public static String decryptCaesar(String encryptedText, int key) {
		// throw new RuntimeException("method not implemented");

		String decrypt = "";
		int x = 0;
		for (int i = 0; i < encryptedText.length(); i++)

		{
			while ((encryptedText.charAt(i) - key) < 31 || (encryptedText.charAt(i) - key > 95)) {
				key = key - 64;
			}

			if (encryptedText.charAt(i) - key == 32) {
				x = 32;
			} else {

				x = (encryptedText.charAt(i) - key);
			}

			decrypt += (char) x;
		}

		return decrypt;
	}

	/**
	 * Decrypts a string according the Bellaso Cipher. Each character in
	 * encryptedText is replaced by the character corresponding to the character in
	 * bellasoStr, which is repeated to correspond to the length of plainText. This
	 * is the inverse of the encryptBellaso method.
	 * 
	 * @param encryptedText
	 *            an uppercase string to be encrypted.
	 * @param bellasoStr
	 *            an uppercase string that specifies the offsets, character by
	 *            character.
	 * @return the decrypted string
	 */
	public static String decryptBellaso(String encryptedText, String bellasoStr) {
		// throw new RuntimeException("method not implemented");
		int j = 0;
		String extendedKey = "";
		String decryptCode = "";
		for (int i = 0; i < encryptedText.length(); i++) {

			int v = bellasoStr.length();
			if (j == v) {
				j = 0;
			}

			extendedKey += (bellasoStr.charAt(j));
			j++;

		}

		int z = 0;
		for (int i = 0; i < encryptedText.length(); i++) {

			z = ((encryptedText.charAt(i) - extendedKey.charAt(i)));

			while (z < 32) {
				z = z + 64;
			}
			decryptCode += (char) z;
		}

		return decryptCode;
	}
}