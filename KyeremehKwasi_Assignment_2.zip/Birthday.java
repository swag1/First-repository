//Programmer Name: Kwasi Kyeremeh
import java.text.DecimalFormat;
import java.util.Optional;
import java.util.Random;
import java.util.Scanner;

public class Birthday {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name = ""; // name of the child
		String toy = ""; // one of the three toys available
		String numInput; // number from keyboard as a string
		String yesOrNo = " "; // user response from keyboard
		String add = " "; // yes or no to add a card or balloon
		String ageCheck = " "; // yes or no from the keyboard
		int age; // numeric input for age
		double cost = 0; // running total cost for the order
		// Create a DecimalFormat object for dollar formatting.
		DecimalFormat dollar = new DecimalFormat("#,##0.00");
		Toy t;
		// ================================================================================
		Scanner sc = new Scanner(System.in);

		do {

			System.out.println("Enter the name of the child");
			name = sc.nextLine();

			// enter the age of the child and convert to integer
			System.out.println("How old is the child?");
			age = sc.nextInt();
			sc.nextLine();

			// begin loop to input toy
			do {
				// enter the type of toy

				System.out.println("Choose a toy: a plushie, blocks, or a book");
				toy = sc.nextLine();

				// while loop to validate toy choice
				while (!(toy.equalsIgnoreCase("plushie") || toy.equalsIgnoreCase("blocks")
						|| toy.equalsIgnoreCase("book"))) {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      
					System.out.println("Invalid choice\nPlease choose again");
					System.out.println("Choose a toy: a plushie, blocks, or a book");
					toy = sc.nextLine();
				}

				// create a Toy object
				t = new Toy(toy, age);

				// check if age-appropriate
				if (t.ageOK()) {
					System.out.println("Good Choice!");

					ageCheck = "no";
				}

				else {
					// check if toy is age-appropriate
					System.out
							.println("Toy is not age-appropriate\n" + "Do you want to buy a different toy? Yes or No ");
					ageCheck = sc.nextLine();

				}
			} while (ageCheck.equalsIgnoreCase("yes"));// get a different toy

			// add
			// cards========================================================================
			// check if a card or balloon should accompany the gift
			System.out.println("Do you want a card with the gift? Yes or No");
			yesOrNo = sc.nextLine();

			t.addCard(yesOrNo);

			// add
			// baloons===========================================================================

			System.out.println("Do you want a balloon with the gift? Yes or No");
			yesOrNo = sc.nextLine();

			t.addBalloon(yesOrNo);

			// Display on the console the cost for one toy
			System.out.println("The gift for " + name + t);
			cost += t.getCost(); // add toy cost to total
			System.out.println("Do you want another gift? Yes or No");
			yesOrNo = sc.nextLine();

		} while (yesOrNo.equalsIgnoreCase("yes"));

		// output total cost of order

		System.out.println("\nThe total cost of your order is $" + dollar.format(cost));
		// Generate a random order number
		Random rand = new Random();
		int order = rand.nextInt(100000) + 1;
		System.out.println("\nOrder number is " + order);
     
		System.exit(0);

	}     
}
